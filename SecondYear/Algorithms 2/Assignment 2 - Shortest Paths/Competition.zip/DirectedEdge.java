
public class DirectedEdge {
	
	int from;
	int to;
	double weight;
	
	
	DirectedEdge(int from, int to, double weight) {
		this.from = from;
		this.to = to;
		this.weight = weight;
	}

}
